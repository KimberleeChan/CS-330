///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	bool bReturn = false;

	bReturn = CreateGLTexture(
		"textures/chinese-dragon-1372435525mzm.jpg",
		"notebook");

	bReturn = CreateGLTexture(
		"textures/pencil-body.jpg",
		"pencilBody");

	bReturn = CreateGLTexture(
		"textures/grey-grunge.jpg",
		"graphite");

	bReturn = CreateGLTexture(
		"textures/grid.jpg",
		"table");

	bReturn = CreateGLTexture(
		"textures/clip.jpg",
		"clip");

	bReturn = CreateGLTexture(
		"textures/white-on-white-background.jpg",
		"eraser");

	bReturn = CreateGLTexture(
		"textures/metallic-silver-background-1524893710Zdd.jpg",
		"can");

	bReturn = CreateGLTexture(
		"textures/vintage-album-hintergrund-floral-1680893952YdI.jpg",
		"book");

	bReturn = CreateGLTexture(
		"textures/white-on-white-background.jpg",
		"pages");

	bReturn = CreateGLTexture(
		"textures/textur-hintergrund-vintage-violett.jpg",
		"dice");

	BindGLTextures();

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadPyramid4Mesh();
	m_basicMeshes ->LoadTorusMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// Enables lighting
	m_pShaderManager->setIntValue(g_UseLightingName, true);

	// Adds point light above the tabletop scene
	m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(-5.0f, 20.0f, -13.0f));
	m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.2f, 0.2f, 0.2f));
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(0.5f, 0.5f, 0.5f));
	m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(0.5f, 0.5f, 0.5f));
	m_pShaderManager->setIntValue("pointLights[0].bActive", true);

	// Adds point light above the tabletop scene
	m_pShaderManager->setVec3Value("pointLights[1].position", glm::vec3(35.0f, 20.0f, -13.0f));
	m_pShaderManager->setVec3Value("pointLights[1].ambient", glm::vec3(0.2f, 0.2f, 0.2f));
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", glm::vec3(0.5f, 0.5f, 0.5f));
	m_pShaderManager->setVec3Value("pointLights[1].specular", glm::vec3(0.5f, 0.5f, 0.5f));
	m_pShaderManager->setIntValue("pointLights[1].bActive", true);

	// Warm yellow back light
	m_pShaderManager->setVec3Value("pointLights[2].position", glm::vec3(35.0f, 20.0f, 35.0f));
	m_pShaderManager->setVec3Value("pointLights[2].ambient", glm::vec3(0.02f, 0.02f, 0.01f));
	m_pShaderManager->setVec3Value("pointLights[2].diffuse", glm::vec3(0.2f, 0.19f, 0.16f));
	m_pShaderManager->setVec3Value("pointLights[2].specular", glm::vec3(0.1f, 0.09f, 0.07f));
	m_pShaderManager->setIntValue("pointLights[2].bActive", true);
	
	// Adds material properties
	m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(1.0f, 1.0f, 1.0f));
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.2f, 0.2f, 0.2f));
	m_pShaderManager->setFloatValue("material.shininess", 32.0f);

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/

	// Draws the table
	DrawTable();

	// Draws the pencil
	DrawPencil();

	// Draws the notebook
	DrawNotebook();

	// Draws the first Pathfinder book
	DrawBook(
		glm::vec3(9.0f, 0.8f, 0.0f),
		glm::vec3(9.13f, 0.8f, 0.0f),
		0.0f);

	// Draws the second Pathfinder book
	DrawBook(
		glm::vec3(9.5f, 2.3f, -0.2f),
		glm::vec3(9.63f, 2.3f, -0.26f),
		25.0f);

	// Draws the Diet Coke can
	DrawCan();

	// Draws d6
	DrawD6();

	// Draws d4
	DrawD4();

	// Draws d8
	DrawD8();
}


void SceneManager::DrawTable()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(50.0f, 1.0f, 23.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(16.0f, 0.0f, -13.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("table");
	SetTextureUVScale(4.0f, 2.0f);

	// Adds material for table surface
	m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(1.0f, 1.0f, 1.0f));
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.2f, 0.2f, 0.2f));
	m_pShaderManager->setFloatValue("material.shininess", 4.0f);

	m_basicMeshes->DrawPlaneMesh();
}

/****************************************************
*                   DrawPencil()                    *
*                                                   *
* Draws the pencil using multiple primitive meshes. *
*****************************************************/
void SceneManager::DrawPencil()
{
	// Cone for pencil tip
	SetTransformations(
		glm::vec3(0.2f, 0.95f, 0.2f),
		90.0f, -29.0f, 0.0f,
		glm::vec3(-4.83f, 1.62f, 5.4f));

	SetShaderTexture("pencilBody");
	m_basicMeshes->DrawConeMesh();

	// Cylinder for pencil body
	SetTransformations(
		glm::vec3(0.2f, 8.0f, 0.2f),
		90.0f, -29.0f, 0.0f,
		glm::vec3(-0.95f, 1.62f, -1.6f));

	SetShaderTexture("pencilBody");
	SetTextureUVScale(5.0f, 10.0f);
	m_basicMeshes->DrawCylinderMesh();

	// First box for pencil clip
	SetTransformations(
		glm::vec3(0.2f, 2.1f, 0.4f),
		90.0f, -29.0f, 0.0f,
		glm::vec3(-2.0f, 1.62f, -0.5f));

	SetShaderTexture("clip");
	m_basicMeshes->DrawBoxMesh();

	// Second box for pencil clip
	SetTransformations(
		glm::vec3(0.2f, 0.9f, 0.3f),
		90.0f, -29.0f, 0.0f,
		glm::vec3(-1.6f, 1.62f, -0.86f));

	SetShaderTexture("clip");
	m_basicMeshes->DrawBoxMesh();

	// First cylinder for pencil end
	SetTransformations(
		glm::vec3(0.15f, 0.5f, 0.15f),
		90.0f, -29.0f, 0.0f,
		glm::vec3(-0.73f, 1.62f, -2.0f));

	SetShaderTexture("clip");
	m_basicMeshes->DrawCylinderMesh();

	// Second cylinder for pencil end
	SetTransformations(
		glm::vec3(0.2f, 0.4f, 0.2f),
		90.0f, -29.0f, 0.0f,
		glm::vec3(-0.62f, 1.62f, -2.2f));

	SetShaderTexture("clip");
	m_basicMeshes->DrawCylinderMesh();

	// Cylinder for pencil eraser
	SetTransformations(
		glm::vec3(0.16f, 0.4f, 0.16f),
		90.0f, -29.0f, 0.0f,
		glm::vec3(-0.5f, 1.62f, -2.4f));

	SetShaderTexture("eraser");
	m_basicMeshes->DrawCylinderMesh();

	// Cylinder for pencil lead
	SetTransformations(
		glm::vec3(0.03f, 2.21f, 0.03f),
		90.0f, -29.0f, 0.0f,
		glm::vec3(-4.22f, 1.62f, 4.3f));

	SetShaderTexture("graphite");
	m_basicMeshes->DrawCylinderMesh();
}

/***************************************
 *          DrawNotebook()             *
 *                                     *
 * Draws the notebook cover and pages. *
 ***************************************/
void SceneManager::DrawNotebook()
{
	// Draws the notebook cover
	SetTransformations(
		glm::vec3(7.75f, 1.4f, 12.0f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(-2.5f, 0.72f, 2.3f));

	SetShaderTexture("notebook");
	SetTextureUVScale(0.33f, 0.33f);
	m_basicMeshes->DrawBoxMesh();

	// Draws the notebook pages
	SetTransformations(
		glm::vec3(7.5f, 1.25f, 12.01f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(-2.37f, 0.75f, 2.3f));

	SetShaderTexture("pages");
	SetTextureUVScale(0.33f, 0.33f);
	m_basicMeshes->DrawBoxMesh();
}

/************************************************************
 *                    DrawBook()                            *
 *                                                          *
 * Draws a book cover and its pages at a specified position *
 * and Y rotation.                                          *
 ************************************************************/
void SceneManager::DrawBook(glm::vec3 positionXYZ, glm::vec3 pagesPositionXYZ, float YrotationDegrees)
{
	// Draws the book cover
	SetTransformations(
		glm::vec3(10.5f, 1.5f, 14.5f),
		0.0f, YrotationDegrees, 0.0f,
		positionXYZ);

	SetShaderTexture("book");
	m_basicMeshes->DrawBoxMesh();

	// Draws the book pages
	SetTransformations(
		glm::vec3(10.25f, 1.35f, 14.51f),
		0.0f, YrotationDegrees, 0.0f,
		pagesPositionXYZ);

	SetShaderTexture("pages");
	m_basicMeshes->DrawBoxMesh();
}

/*************************************************************
 *                      DrawCan()                            *
 *                                                           *
 * Draws the can using two tapered cylinders and a cylinder. *
 *************************************************************/
void SceneManager::DrawCan()
{
	// Draws lip of the can
	SetTransformations(
		glm::vec3(1.5f, 1.5f, 0.8f),
		89.5f, 0.0f, 0.0f,
		glm::vec3(-9.26f, 6.2f, -5.26f));

	SetShaderTexture("can");
	SetTextureUVScale(1.0f, 1.0f);
	m_pShaderManager->setFloatValue("material.shininess", 8.0f);
	m_pShaderManager->setVec3Value(
		"material.diffuseColor",
		glm::vec3(0.85f, 0.85f, 0.90f));
	m_basicMeshes->DrawTorusMesh();


	// Draws the body of the can
	SetTransformations(
		glm::vec3(1.8f, 6.0f, 1.8f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(-9.25f, 0.2f, -5.25f));

	SetShaderTexture("can");
	SetTextureUVScale(0.5f, 0.5f);
	m_pShaderManager->setFloatValue("material.shininess", 8.0f);
	m_pShaderManager->setVec3Value(
		"material.diffuseColor",
		glm::vec3(0.85f, 0.85f, 0.90f));
	m_basicMeshes->DrawCylinderMesh();

	// Draws the bottom of the can
	SetTransformations(
		glm::vec3(1.8f, 0.2f, 1.8f),
		180.0f, 0.0f, 0.0f,
		glm::vec3(-9.25f, 0.2f, -5.25f));

	SetShaderTexture("can");
	SetTextureUVScale(1.0f, 1.0f);
	m_pShaderManager->setFloatValue("material.shininess", 8.0f);
	m_pShaderManager->setVec3Value(
		"material.diffuseColor",
		glm::vec3(0.85f, 0.85f, 0.90f));
	m_basicMeshes->DrawTaperedCylinderMesh();
}

/***********************************
 *           DrawD6()              *
 *                                 *
 * Draws the die using a box mesh. *
 ***********************************/
void SceneManager::DrawD6()
{
	// Draws the die
	SetTransformations(
		glm::vec3(0.9f, 0.9f, 0.9f),
		0.0f, 5.0f, 0.0f,
		glm::vec3(-0.4f, 0.45f, -8.0f));

	SetShaderTexture("dice");
	m_basicMeshes->DrawBoxMesh();
}

/***************************************
 *              DrawD4()               *
 *                                     *
 * Draws the die using a pyramid mesh. *
 ***************************************/
void SceneManager::DrawD4()
{
	// Draws the die
	SetTransformations(
		glm::vec3(0.9f, 0.9f, 0.9f),
		0.0f, 30.0f, 0.0f,
		glm::vec3(-1.9f, 0.45f, -6.15f));

	SetShaderTexture("dice");
	m_basicMeshes->DrawPyramid4Mesh();
}

/***************************************
 *              DrawD8()               *
 *                                     *
 * Draws the die using 2 pyramid mesh. *
 ***************************************/
void SceneManager::DrawD8()
{
	// Draws top of die
	SetTransformations(
		glm::vec3(0.8f, 0.8f, 0.8f),
		296.5f, 0.0f, 0.0f,
		glm::vec3(-2.9f, 0.535f, -8.116f));
	
	SetShaderTexture("dice");
	m_basicMeshes->DrawPyramid4Mesh();

	// Draws bottom of die
	SetTransformations(
		glm::vec3(0.8f, 0.8f, 0.8f),
		116.5f, 0.0f, 0.0f,
		glm::vec3(-2.9f, 0.179f, -7.4f));

	SetShaderTexture("dice");
	m_basicMeshes->DrawPyramid4Mesh();
}